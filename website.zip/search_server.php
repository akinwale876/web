


<?php


require 'connection.php';


?>


<html lang="en-US" prefix="og: http://ogp.me/ns#" class="no-js"> 
   
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?php 



include 'head.php';





if (isset($_GET['q'])){




$qq = $_GET['q'];



?>

 <title><?php echo 'Results For "' . $qq .'"';?></title>



		
<meta http-equiv="x-ua-compatible" content="IE=edge,chrome=1" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    
    
    
    
    
    <body>
        
    
<?php



include 'header.php';



?>
        
        
     <div class="wrapper">
         
        
              <div class="main" style="color:black;">
                 
                 
                 
                 
                 
                 
                 
                 


<?php


if(isset($_GET['category'])){

if($_GET['category'] == 'post'){


$post_query = mysqli_query($conn,"SELECT * FROM posts  WHERE `title` like '%$qq%' OR `content` like '%$qq%' OR `tag` like '%$qq%'  LIMIT 11");


  echo    '<br><br><h3 style="text-indent:20px;"> '. '<span style="color:gold;">'.mysqli_num_rows($post_query).'</span>' . ' Results Found For ' . '"' . $qq . '"</h3><br/>';


while($data = mysqli_fetch_array($post_query)){
    


$title = $data['title'];
$category = $data['category'];
$description= substr($data['description'],0,60);

$image = $data['picture_url'];

$cleanurl = $data['cleanurl'];

$date = $data['date'];

$date = date('m:ha   l d-M-Y', $date);


echo '<a style="text-decoration:none;color:black;" href="http://'. $_SERVER["SERVER_NAME"].'/'.$category.'/'.$cleanurl.'">

<div class="post" style="position:relative;">
<img alt="'.$list_title.'" class="img" src="'.$image. '">

<div class="post-title">
<h4 style="margin-bottom:8px;">'. ucfirst($title).'</h4>
<br>
<span class="hov" style="padding:3px;font-size:9px;>'.$category.'</span>


<b style="color:rgb(10,10,100);position:absolute;left:9px;bottom:10px;"><small><i class="fa fa-clock">'. $date .'</i>
</small><span style="margin-left:5px;color:red;font-size:10px;"><i class="fa fa-eye"></i>'.$views.' views</span></b><br><span class="content" id="one" style="color:rgb(140,140,140);font-family: Source Sans Pro,sans-serif 
;">
<span class="hov" style="padding:3px;font-size:9px;border:none;font-weight:bold;"><i class="fa fa-comment"></i>'.$num_post_query.'</span>
'. str_replace('h2','',str_replace('<h1>','',substr($description,0,120))) .'</span><span style="color:brown;font-weight:bold;margin-left:4px;font-size:9px;"></span>

</div>


    
</div></a>';







}


}


if($_GET['category'] == 'movie'){


$post_query = mysqli_query($conn,"SELECT * FROM movies  WHERE `title` like '%$qq%' OR `short_story` like '%$qq%' LIMIT 11");


  echo    '<br><br><h3 style="text-indent:20px;"> '. '<span style="color:gold;">'.mysqli_num_rows($post_query).'</span>' . ' Results Found For ' . '"' . $qq . '"</h3><br/>';


while($data = mysqli_fetch_array($post_query)){
    


$title = $data['title'];
$category = $data['category'];
$description= substr($data['short_story'],0,60);

$image = $data['picture_url'];

$cleanurl = $data['cleanurl'];

$date = $data['date'];

$date = date('m:ha   l d-M-Y', $date);


echo '<a style="text-decoration:none;color:black;" href="https://'. $_SERVER["SERVER_NAME"].'/movie/'.$cleanurl.'">

<div class="post" style="position:relative;">
<img alt="'.$list_title.'" class="img" src="'.$image. '">

<div class="post-title">
<h4 style="margin-bottom:8px;">'. ucfirst($title).'</h4>
<br>
<span class="hov" style="padding:3px;font-size:9px;>'.$category.'</span>


<b style="color:rgb(10,10,100);position:absolute;left:9px;bottom:10px;"><small><i class="fa fa-clock">'. $date .'</i>
</small><span style="margin-left:5px;color:red;font-size:10px;"><i class="fa fa-eye"></i>'.$views.' views</span></b><br><span class="content" id="one" style="color:rgb(140,140,140);font-family: Source Sans Pro,sans-serif 
;">
<span class="hov" style="padding:3px;font-size:9px;border:none;font-weight:bold;"><i class="fa fa-comment"></i>'.$num_post_query.'</span>
'. str_replace('h2','',str_replace('<h1>','',substr($description,0,120))) .'</span><span style="color:brown;font-weight:bold;margin-left:4px;font-size:9px;"></span>

</div>


    
</div></a>';







}


}





if($_GET['category'] == 'music'){


$post_query = mysqli_query($conn,"SELECT * FROM music  WHERE `title` like '%$qq%' OR `content` like '%$qq%' LIMIT 11");


  echo    '<br><br><h3 style="text-indent:20px;"> '. '<span style="color:gold;">'.mysqli_num_rows($post_query).'</span>' . ' Results Found For ' . '"' . $qq . '"</h3><br/>';


while($data = mysqli_fetch_array($post_query)){
    


$title = $data['title'];
$category = $data['category'];
$description= substr($data['description'],0,60);

$image = $data['picture_url'];

$cleanurl = $data['cleanurl'];

$date = $data['date'];

$date = date('m:ha   l d-M-Y', $date);


echo '<a style="text-decoration:none;color:black;" href="https://'. $_SERVER["SERVER_NAME"].'/music/'.$cleanurl.'">

<div class="post" style="position:relative;">
<img alt="'.$list_title.'" class="img" src="'.$image. '">

<div class="post-title">
<h4 style="margin-bottom:8px;">'. ucfirst($title).'</h4>
<br>
<span class="hov" style="padding:3px;font-size:9px;>'.$category.'</span>


<b style="color:rgb(10,10,100);position:absolute;left:9px;bottom:10px;"><small><i class="fa fa-clock">'. $date .'</i>
</small><span style="margin-left:5px;color:red;font-size:10px;"><i class="fa fa-eye"></i>'.$views.' views</span></b><br><span class="content" id="one" style="color:rgb(140,140,140);font-family: Source Sans Pro,sans-serif 
;">
<span class="hov" style="padding:3px;font-size:9px;border:none;font-weight:bold;"><i class="fa fa-comment"></i>'.$num_post_query.'</span>
'. str_replace('h2','',str_replace('<h1>','',substr($description,0,120))) .'</span><span style="color:brown;font-weight:bold;margin-left:4px;font-size:9px;"></span>

</div>


    
</div></a>';







}


}









}





















}



?>
   
   
   
                 
                 
              </div>
         
         
         
         
         
         
         
         
<?php




include 'sidebar.php';



?>


         
         
         
         
         
         
     </div>   
        
        
        
        
        
       
       
       
       
       
       
<?php



include 'footer.php';



?> 
        
    </body>
    
    
    
    
    
    
    
    
    
    
    
    
    
</html>


