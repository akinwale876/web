<br><br><br>



<div class="footer"  style="background:rgb(10,10,10);">

<br>


<div class="header-content" style="clear:both;">
    
    
    
<center> 
  
      
    <br>
      <center> 
<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fnaijaramz%2F&tabs&width=340&height=214&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=358510268151781" width="50%" height="164" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

</center>
    <h5 style="color:red;">Special Notice</h5>
     <p class="p"  style="font-family:cursive;font-size:11px;color:rgb(200,270,250);">
NaijaRamz.com do not claim any ownership of music and videos that we upload any  copyright infringement complaints will be executed immediately! It our right to honor all take-down request! Email Us via <em>abuse@naijaramz.com</em>
</p>

       </center>
 
        </div>
<?php

include "list2.php";

?>
<p style="color:rgb(100,100,100);font-weight:400;">
    
    
   
<small style="font-size:9px;">

<script language="JavaScript">

document.write('&copy;' );
document.write(' <b><i>NaijaRamz</i> ');
document.write(new Date().getFullYear());
document.write(' </b> Alright Reserved');

</script>

</small>
 
</p>
<style>
    
    p{
        font-size:11px;
        color:#07240f;
    }
</style>



<?php

include 'scroller.php';


?>




<div style="padding:8px;">
    
    <center>
        
    <a style="color:rgb(140,140,140);cursor:pointer;font-size:13px;font-family:cursive;" href="https://<?php echo $_SERVER['SERVER_NAME']?>/promote.php">
Promote with us</a> 



    <a style="color:rgb(200,40,40);cursor:pointer;font-size:13px;margin-left:9px;font-family:cursive;" href="https://<?php echo $_SERVER['SERVER_NAME']?>/welcome.php">
<?php if(isset($firstname)){
echo 'Write Post';}else{
    echo 'Write For Us';
}

?></a>
        
        
    </center>
    
</div>




</div>


<?php

if(!isset($_COOKIE['cat'])){


echo '<div style="position:fixed;box-shadow:0px 4px 4px 0px rgb(130,20,20);display:inline-block;z-index:1;background:rgb(240,240,240);padding-top:0;display:none;width:97%;" class="container">
    
    <div style="position:relative;">

        
        <span style="background:rgb(200,200,200); border-radius:8px;position:absolute;right:4px;top:0;color:rgb(100,0,0);padding:5px;font-size:9px;font-weight:bold;cursor:pointer;" id="remove">Accept</span></div>
    
    <div style="overflow:auto;padding:8px;">
        
<center>

<p style="font-size:12px;  ">By continuing to browse or by clicking “Accept Cookies,” you agree to the storing of first- and third-party cookies on your device to enhance site navigation, analyze site usage, and assist in our marketing efforts. Read
 more at <a href="https://naijaramz.com/privacy-policy">policy</p>

</center> 


    </div>
    
    
</div>';
}

?>





<script>

var nnn;


nnn = 0;


    setInterval(function(){

if(nnn == 0){
            
            $('.container').slideDown(200);
            $('html').animate({backroundColor: 'gray'});
                        $('.container').animate({backroundColor: 'white',left:"10px",bottom:"10px"});

}
 
        
    },6000);
   
    
    
    $('#remove').click(function(){
        
            $('html').animate({opacity: '1'});
                    $('.container').animate({left:"0",top:"0"}, 'fast');

                    $('.container').slideUp(10);

    
    nnn = 1;    
    });
    
    
    
    $('#rem').click(function(){
        
            $('html').animate({opacity: '1'});
                    $('.container').animate({left:"0",top:"0"}, 'fast');

                    $('.container').slideUp(10);

    
    nnn = 1;    
    });
    
    

</script>


<style>
    
    
    .sit::after{
        
        content:"";
        position:absolute;
        top:100%;
        left:30%;
        border-width:4px;
        border-color:rgb(200,40,40) transparent  transparent  transparent ;
        border-style:solid;
        
    }
    
</style>



