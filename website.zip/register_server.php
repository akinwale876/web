<?php

require 'connection.php';







$errors = array();


if($conn){


    echo '<span style="color:green;font-size:9px;">conneted</span>';
}

if(isset($_POST['firstname'])){


if(!empty($_POST['firstname'])){


if(strlen($_POST['firstname']) > 3){

$firstname = $_POST['firstname'];


}else{

    array_push($errors, '<span style="color:red;">first name length must be greater than 6</span>');


}











}else{
    array_push($errors, '<span style="color:red;">first name is blank</span>');


}





}
else{

    array_push($errors, 'first name is required');
}









if(isset($_POST['lastname'])){

    if(!empty($_POST['lastname'])){


if(strlen($_POST['lastname']) > 2){


$lastname = $_POST['lastname'];




}else{

    array_push($errors, '<span style="color:red;">last name length must be greater than 2</span>');


}









    }else{

            array_push($errors, '<span style="color:red;">last name is blank</span>');

    }





}
else{

    array_push($errors, 'lastname is required');
}



















if(isset($_POST['email'])){

    if(!empty($_POST['email'])){


if(strlen($_POST['email']) > 3){


$email = $_POST['email'];


}else{

    array_push($errors, '<span style="color:red;">email length must be greater than 100 characters</span>');


}















    }else{
    array_push($errors, '<span style="color:red;">email is blank</span>');


    }







}
else{

    array_push($errors, 'email is required');
}








if(isset($_POST['password'])){

    if(!empty($_POST['password'])){


if(strlen($_POST['password']) > 3){


$password = $_POST['password'];
$password = md5($password);


}else{

    array_push($errors, '<span style="color:red;">password length must be greater than 100 characters</span>');


}















    }else{
    array_push($errors, '<span style="color:red;">password is blank</span>');


    }







}
else{

    array_push($errors, 'password is required');
}






if(isset($_POST['confirm'])){

    if(!empty($_POST['confirm'])){



$confirm = $_POST['confirm'];

$confirm = md5($confirm);


    }






}










if($password != $confirm){
    
    
    array_push($errors, '<span style="color:red;"> password do not match </span>');
}








if(empty($errors)){



    


$date = date_create();

 $date = date_timestamp_get($date);



$username = $firstname . substr(uniqid(),0,4);


$ip = $_SERVER['REMOTE_ADDR'];





$query =mysqli_query($conn,"INSERT INTO `author` (`first_name`, `last_name`, `email`, `username`, `password`, `active`, `ip`, `last_login`, `date`) VALUES ('$firstname', '$lastname', '$email', '$username', '$password', '0', '$ip', '$date', '$date')");




if($query){

echo '<span style="color:green;">account created successfully</span>


<li><b> Your username is: '.$username.'</b></li>';
}else{
echo '<span style="color:red;">post failed</span>';


}





}else{


echo '<div style="width:190px;box-shadow:0px 2px 2px 0px rgb(230,230,230);">';

   foreach($errors as $key => $err){

echo ' <p>' .$err . '</p>';
   }


echo '</div>';


}




?>