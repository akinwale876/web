
<?php


require 'connection.php';


?>

<!DOCtype html>
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Forum discusion - Naijaramz talk Zone  </title>

<?php

include "head.php";

?>


<meta name="description" content="this section is naijaramz talk zone where you can ask any question  " />
<link rel="canonical" href="https://naijaramz.com/forum.php" />
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="object" />
</head>


<body>

<?php

include "header.php";

?>

<div class="wrapper" style="color:white;">
    <br>
<h1 style="text-align:center;position:relative;"> Naija Forum 

        <span
      style="position:absolute;top:-25px;padding:2px;display:inline-block;left:40%;color:rgb(200,40,40);font-size:18px;"><i class="fa fa-users"></i></span>
        
</h1>

<center>
    <div style="color:white;margin:10px 0px 30px 0px;padding:10px;">
<p style="color:white;">This forum has been created to help nigeria to discuss politics,lifestyle,jobs/vacancies,business,travels and lot more</p>

<p style="color:white;">Join us </p>
</div>
</center>

<div class="main" style="box-shadow:none;color:black;background:white;">



<?php





require 'questions.php';


?>



</div>

<?php

include "sidebar.php";

?>

</div>


<?php

include "footer.php";

?>

<style>
    
    
    .data:nth-child(even){
        
    background:rgb(249,249,249);
    }
    
  
    
</style>



</body>

</html>