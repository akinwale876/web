
<?php





require 'connection.php';


?>


<!DOCtype
 html>
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>How to guide - Naijaramz</title>



<meta property="og:locale" content="en_US" />
<meta property="og:type" content="object" />
<meta property="og:title" content="how to &raquo; naijaramz" />
<meta property="og:description" content="articles" />
<meta property="og:url" content="https://naijaramz.com/howto.php" />
<meta property="og:site_name" content="naijaramz" />

<?php

include "head.php";

?>


</head>


<body>

<?php

include "header.php";

?>

<div class="wrapper">

<h2>Category: How to</h2>

<div class="main">
    
    
    
<?php



echo '<h5 style="box-shadow:0px 6px 6px 0px rgb(100,100,100);background-color:white;color: black;padding: 8px;font-size:11px;"></span>Telecommunication<span style="text-indent: 10px;"></h5>
' ;


$list_post_query = mysqli_query($conn,"SELECT * FROM posts WHERE category='Telecommunication' ORDER BY id DESC LIMIT 11");






while($mov = mysqli_fetch_array($list_post_query)){

$list_title = $mov['title'];
$list_cleanurl = $mov['cleanurl'];
$list_image = $mov['picture_url'];
$list_description = $mov['description'];
$list_content = $mov['description'];

$list_category = $mov['category'];
$list_comments = $mov['comments'];
$list_comments_id = $mov['comment_id'];
$list_views = $mov['views'];

$list_date = date(' l  d / M / Y',$mov['date']);

$current_date = date_create();

$current_date = date_timestamp_get($current_date);


$count_date = $mov['date'];



$count_date =  ($current_date - $count_date);

$comment_post_query = mysqli_query($conn,"SELECT * FROM `comment` WHERE `comment_id` = '$list_comments_id'");


$num_post_query = mysqli_num_rows($comment_post_query);







  
  $days = floor($count_date / (60 * 60 * 24));
  $hours = floor(($count_date % (60 * 24)) / (1000 * 60 * 60));
 $minutes = floor(($count_date % ( 60)) / (1000 * 60));
 $seconds = floor(($count_date % (1000 * 60)) / 1000);
  
  

    
    $time = $minutes  . ' mins ';
    
$likes = $mov['likes'];
//

echo '<a style="text-decoration:none;color:black;" href="https://'. $_SERVER["SERVER_NAME"].'/'.$list_category.'/'.$list_cleanurl.'">

<div class="post" style="position:relative;">
<img alt="'.$list_title.'" class="img" src="'. str_replace('http','https',$list_image).'">

<div class="post-title">
<h4 style="margin-bottom:8px;">'. ucfirst($list_title).'</h4>
<br>
<span class="hov" style="padding:3px;font-size:9px;>'.$list_category.'</span>


<b style="color:rgb(10,10,100);position:absolute;left:9px;bottom:10px;"><small><i class="fa fa-clock">'. $list_date .'</i>
</small><span style="margin-left:5px;color:red;font-size:10px;"><i class="fa fa-eye"></i>'.$list_views.' views</span></b><br><span class="content" id="one" style="color:rgb(140,140,140);font-family: Source Sans Pro,sans-serif 
;">
<span class="hov" style="padding:3px;font-size:9px;border:none;font-weight:bold;"><i class="fa fa-comment"></i>'.$num_post_query.'</span>
'. str_replace('h2','',str_replace('<h1>','',substr($list_content,0,120))) .'</span><span style="color:brown;font-weight:bold;margin-left:4px;font-size:9px;"></span>

</div>


    
</div></a>';

}



?>







 
    
<?php



echo '<h5 style="box-shadow:0px 6px 6px 0px rgb(100,100,100);background-color:white;color: black;padding: 8px;font-size:11px;"></span>Food<span style="text-indent: 10px;"></h5>
' ;


$list_post_query = mysqli_query($conn,"SELECT * FROM posts WHERE category='food' ORDER BY id DESC LIMIT 11");






while($mov = mysqli_fetch_array($list_post_query)){

$list_title = $mov['title'];
$list_cleanurl = $mov['cleanurl'];
$list_image = $mov['picture_url'];
$list_description = $mov['description'];
$list_content = $mov['description'];

$list_category = $mov['category'];
$list_comments = $mov['comments'];
$list_comments_id = $mov['comment_id'];
$list_views = $mov['views'];

$list_date = date(' l  d / M / Y',$mov['date']);

$current_date = date_create();

$current_date = date_timestamp_get($current_date);


$count_date = $mov['date'];



$count_date =  ($current_date - $count_date);

$comment_post_query = mysqli_query($conn,"SELECT * FROM `comment` WHERE `comment_id` = '$list_comments_id'");


$num_post_query = mysqli_num_rows($comment_post_query);







  
  $days = floor($count_date / (60 * 60 * 24));
  $hours = floor(($count_date % (60 * 24)) / (1000 * 60 * 60));
 $minutes = floor(($count_date % ( 60)) / (1000 * 60));
 $seconds = floor(($count_date % (1000 * 60)) / 1000);
  
  

    
    $time = $minutes  . ' mins ';
    
$likes = $mov['likes'];
//

echo '<a style="text-decoration:none;color:black;" href="http://'. $_SERVER["SERVER_NAME"].'/'.$list_category.'/'.$list_cleanurl.'">

<div class="post" style="position:relative;">
<img alt="'.$list_title.'" class="img" src="'.str_replace('http','https',$list_image).'">

<div class="post-title">
<h4 style="margin-bottom:8px;">'. ucfirst($list_title).'</h4>
<br>
<span class="hov" style="padding:3px;font-size:9px;>'.$list_category.'</span>


<b style="color:rgb(10,10,100);position:absolute;left:9px;bottom:10px;"><small><i class="fa fa-clock">'. $list_date .'</i>
</small><span style="margin-left:5px;color:red;font-size:10px;"><i class="fa fa-eye"></i>'.$list_views.' views</span></b><br><span class="content" id="one" style="color:rgb(140,140,140);font-family: Source Sans Pro,sans-serif 
;">
<span class="hov" style="padding:3px;font-size:9px;border:none;font-weight:bold;"><i class="fa fa-comment"></i>'.$num_post_query.'</span>
'. str_replace('h2','',str_replace('<h1>','',substr($list_content,0,120))) .'</span><span style="color:brown;font-weight:bold;margin-left:4px;font-size:9px;"></span>

</div>


    
</div></a>';

}



?>




 
    
<?php



echo '<h5 style="box-shadow:0px 6px 6px 0px rgb(100,100,100);background-color:white;color: black;padding: 8px;font-size:11px;"></span>Finance<span style="text-indent: 10px;"></h5>
' ;


$list_post_query = mysqli_query($conn,"SELECT * FROM posts WHERE category='finance' ORDER BY id DESC LIMIT 11");






while($mov = mysqli_fetch_array($list_post_query)){

$list_title = $mov['title'];
$list_cleanurl = $mov['cleanurl'];
$list_image = $mov['picture_url'];
$list_description = $mov['description'];
$list_content = $mov['description'];

$list_category = $mov['category'];
$list_comments = $mov['comments'];
$list_comments_id = $mov['comment_id'];
$list_views = $mov['views'];

$list_date = date(' l  d / M / Y',$mov['date']);

$current_date = date_create();

$current_date = date_timestamp_get($current_date);


$count_date = $mov['date'];



$count_date =  ($current_date - $count_date);

$comment_post_query = mysqli_query($conn,"SELECT * FROM `comment` WHERE `comment_id` = '$list_comments_id'");


$num_post_query = mysqli_num_rows($comment_post_query);







  
  $days = floor($count_date / (60 * 60 * 24));
  $hours = floor(($count_date % (60 * 24)) / (1000 * 60 * 60));
 $minutes = floor(($count_date % ( 60)) / (1000 * 60));
 $seconds = floor(($count_date % (1000 * 60)) / 1000);
  
  

    
    $time = $minutes  . ' mins ';
    
$likes = $mov['likes'];
//

echo '<a style="text-decoration:none;color:black;" href="http://'. $_SERVER["SERVER_NAME"].'/'.$list_category.'/'.$list_cleanurl.'">

<div class="post" style="position:relative;">
<img alt="'.$list_title.'" class="img" src="'.str_replace('http','https',$list_image).'">

<div class="post-title">
<h4 style="margin-bottom:8px;">'. ucfirst($list_title).'</h4>
<br>
<span class="hov" style="padding:3px;font-size:9px;>'.$list_category.'</span>


<b style="color:rgb(10,10,100);position:absolute;left:9px;bottom:10px;"><small><i class="fa fa-clock">'. $list_date .'</i>
</small><span style="margin-left:5px;color:red;font-size:10px;"><i class="fa fa-eye"></i>'.$list_views.' views</span></b><br><span class="content" id="one" style="color:rgb(140,140,140);font-family: Source Sans Pro,sans-serif 
;">
<span class="hov" style="padding:3px;font-size:9px;border:none;font-weight:bold;"><i class="fa fa-comment"></i>'.$num_post_query.'</span>
'. str_replace('h2','',str_replace('<h1>','',substr($list_content,0,120))) .'</span><span style="color:brown;font-weight:bold;margin-left:4px;font-size:9px;"></span>

</div>


    
</div></a>';

}



?>



    
<?php



echo '<h5 style="box-shadow:0px 6px 6px 0px rgb(100,100,100);background-color:white;color: black;padding: 8px;font-size:11px;"></span>Others<span style="text-indent: 10px;"></h5>
' ;


$list_post_query = mysqli_query($conn,"SELECT * FROM posts WHERE category='How to' ORDER BY id DESC LIMIT 11");






while($mov = mysqli_fetch_array($list_post_query)){

$list_title = $mov['title'];
$list_cleanurl = $mov['cleanurl'];
$list_image = $mov['picture_url'];
$list_description = $mov['description'];
$list_content = $mov['description'];

$list_category = $mov['category'];
$list_comments = $mov['comments'];
$list_comments_id = $mov['comment_id'];
$list_views = $mov['views'];

$list_date = date(' l  d / M / Y',$mov['date']);

$current_date = date_create();

$current_date = date_timestamp_get($current_date);


$count_date = $mov['date'];



$count_date =  ($current_date - $count_date);

$comment_post_query = mysqli_query($conn,"SELECT * FROM `comment` WHERE `comment_id` = '$list_comments_id'");


$num_post_query = mysqli_num_rows($comment_post_query);







  
  $days = floor($count_date / (60 * 60 * 24));
  $hours = floor(($count_date % (60 * 24)) / (1000 * 60 * 60));
 $minutes = floor(($count_date % ( 60)) / (1000 * 60));
 $seconds = floor(($count_date % (1000 * 60)) / 1000);
  
  

    
    $time = $minutes  . ' mins ';
    
$likes = $mov['likes'];
//

echo '<a style="text-decoration:none;color:black;" href="http://'. $_SERVER["SERVER_NAME"].'/'.$list_category.'/'.$list_cleanurl.'">

<div class="post" style="position:relative;">
<img alt="'.$list_title.'" class="img" src="'.str_replace('http','https',$list_image).'">

<div class="post-title">
<h4 style="margin-bottom:8px;">'. ucfirst($list_title).'</h4>
<br>
<span class="hov" style="padding:3px;font-size:9px;>'.$list_category.'</span>


<b style="color:rgb(10,10,100);position:absolute;left:9px;bottom:10px;"><small><i class="fa fa-clock">'. $list_date .'</i>
</small><span style="margin-left:5px;color:red;font-size:10px;"><i class="fa fa-eye"></i>'.$list_views.' views</span></b><br><span class="content" id="one" style="color:rgb(140,140,140);font-family: Source Sans Pro,sans-serif 
;">
<span class="hov" style="padding:3px;font-size:9px;border:none;font-weight:bold;"><i class="fa fa-comment"></i>'.$num_post_query.'</span>
'. str_replace('h2','',str_replace('<h1>','',substr($list_content,0,120))) .'</span><span style="color:brown;font-weight:bold;margin-left:4px;font-size:9px;"></span>

</div>


    
</div></a>';

}



?>



</div>


<?php

include "sidebar.php";

?>

</div>


<?php

include "footer.php";

?>


</body>

</html>