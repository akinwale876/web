<?php
session_start();

include 'guest.php';


?>

<script   src="https://naijaramz.com/jquery.js"></script>

<link rel="stylesheet" href="https://naijaramz.com/style.css" />


<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700|Roboto|Lato:400,900|Source+Sans+Pro:400,700|Montserrat:800" rel="stylesheet">


<link rel="stylesheet" href="https://naijaramz.com/stylemobile.css"/>


<meta name="google-site-verification" content="X5XY3uz3nHWPx8LRUfpFI7ir1rc7lACRIzLzfoBjIUg" />

<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=yes">


<!--.........................google adsense......................-->






<!--.........................google adsense......................-->






<link href="//db.onlinewebfonts.com/c/2cb3e62148b528138a35061500162dee?family=Nasalization" rel="stylesheet" type="text/css"/>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156981103-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-156981103-1');
</script>






 <link rel="icon"  type="images/x-icon" href="https://naijaramz.com/14763d33-d8f5-4a53-b4f8-10263d9de8b3_200x200.jpg">.

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
