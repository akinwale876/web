<div class="header" style="" id="nav">


<?php

include "admin_init.php";

?>


<div class="left-header" style="position:relative;">
    
    
    

<a href="https://<?php echo $_SERVER['SERVER_NAME']?>"><div class="header-image">  

</div>

</a>  

<span class="info" style="font-size:10px;font-family:cursive;margin-top:19px;">We provide you with Telecommunication/
browsing tips,Sport news,music,Fashion and Style,songs lyrics,Entertainment,Gossips,Nollywood and lots more</span>
  
 

</div>


<label style="color:rgb(200,40,40);font-size:9px;position:absolute;top:5px;right:5px;font-family:'Lato';">
    Welcome: 
    <img src="https://naijaramz.com/profile/computer-icons-portable-network-graphics-user-profile-avatar-png-favpng-L1ihcbxsHbnBKBvjjfBMFGbb7.jpg" style="width:20px;height:10px;border-radius:40%;">
Guest</label>



<span  style="margin-right:20px;float:right;">
<a style="color:black;font-family:cursive;font-size:9px;inline-height:28px;"><img style="height:10px;width:15px;margin-right:1px;" src="https://naijaramz.com/images/plug.png"  />Connect with Us</a>
<a target="blank" href="https://www.facebook.com/naijaramz"><img style="height:10px;width:10px;margin-left:5px;" src="https://naijaramz.com/icons/facebook.png"  /></a>

<a target="blank" href="https://www.twitter.com/naija_ramz"><img style="height:10px;width:10px;margin-left:5px;" src="https://naijaramz.com/icons/twitter.png
"  /></a>
<a target="blank"  href="https://www.instagram.com/naijaramz"><img style="height:10px;width:10px;margin-left:5px;" src="https://naijaramz.com/icons/instagram.png
" /></a><a target="blank"  href="https://api.whatsapp.com/send?phone=2348179448515&text=Welcome%20Naijaramz.com"><img style="height:10px;width:14px;margin-left:5px;" src="https://naijaramz.com/icons/whatsapp.png

" /></a>
</span>

<br>

<br>




<?php

include "list.php";

?>



    </div>
    
    
