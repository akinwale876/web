
<?php


session_start();




if(!isset($_SESSION['access'])){
    
    header('location: http://naijaramz.com/login');
}




include 'head.php';

?>

<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">


	<title>Add Video - Naija Ramz </title>

    

</head>
<body>
    
    
    <?php
    
    
    include 'header.php';
    
    
    ?>

                       <center><h1>Post to Naija Ramz  <small style="font-size:11px;"><i class="fa fa-book">Select Category</i></small>




<select name="Category" id="category">
  <option>select</option>
  <option>Yoruba Movie</option>
  <option>Hollywood Movie</option>
  <option>Hausa Movie</option>
  <option>Comedy</option>

</select>
</h1></center>

           <div class="wrapper">

                            
                            <form name="form" action="/" method="get" onsubmit="return false">

<div class="input-container">
  
<input type="text"  id="title" placeholder="Enter Title">


<span class="input-error-report"></span>

</div>
<div class="input-container">
  
<input type="text"  id="tag" placeholder="Enter Tag">


<span class="input-error-report"></span>

</div>

<div class="input-container">
  


<input type="text" id="description" placeholder="Description">
<span class="input-error-report"></span>

</div>




<div class="input-container">
  


<input type="text" id="videoid" placeholder="Video Id">
<span class="input-error-report"></span>

</div>

<br>


<center>
    <div style="width:35%;border:1px solid rgb(210,210,200);">
<input style="border:none;" type="file"  id="file">
</div>
</center>
  <br>


<textarea rows="11" id="content" style="width:90%;padding:2px;" name="content" placeholder="Content..."></textarea>

<br>
<input type="submit"  name="submit" onclick="uploadMovie()" id="ddd" value="Submit!">

</form>

           
           
           
           </div>





<?php


include 'footer.php';

?>



<script src="moviepost.js"></script>

<div class="boot" id="boot" style="width:30%;height:200px;position:fixed;bottom:-30px;left:-30px;display:none;background:white;box-shadow:0px 8px 8px 0px rgb(200,200,200);">
    <h6 style="background:black;margin:0;padding:6px;"><progress id="progressbar" value="" max="100"></progress><span style="color:red;float:right;cursor:pointer;" onclick="$(this).parent().parent().fadeOut(1000)">&times;</span></h6>

    <div style="padding:5px;">
        
<small id="status"></small>
               
<small id="loaded"></small>
               

           
        
    </div>
           
           <script>
           
           
           
           function laterClose(){
               
               
               setTimeout(function(){
                      
                      $('#boot').fadeOut(100);
                   
               },9000)
           }
           
           
               
                     $('#ddd').click(function(){
                         
                         
                              $('.boot').slideDown('fast');
                              $('.boot').animate({left:"31%",top:"28%"},"fast");
                              
                              
                              
                              laterClose();
                         
                     });
                  
           </script>
</div>

</body>
</html>