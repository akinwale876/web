
<?php


session_start();




if(!isset($_SESSION['access'])){
    
    header('location: http://naijaramz.com/login');
}




include 'head.php';

?>

<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">


	<title>Uplaod Music - Naija Ramz </title>

    

</head>



<body>

<?php

include 'header.php';


?>



                       <center><h1>Upload Music to Naija Ramz  <small style="font-size:11px;"><i class="fa fa-book">Select Category</i></small>




<select  name="category">
  <option>select</option>
  <option>Hip Hop</option>
</select>
<a style="color:red;font-size:10px;" href="http://naijaramz.com/Music">check list</a></h1></center>

           <div class="wrapper">

                            
<form name="form" action="musicpost_server.php" method="post" enctype="multipart/form-data">

<div class="input-container">
  
<input type="text"  name="title" placeholder="Enter Title">


<span class="input-error-report"></span>

</div>
<div class="input-container">
  
<input type="text"  name="tag" placeholder="Enter Tag">


<span class="input-error-report"></span>

</div>

<div class="input-container">
  


<input type="text" name="description" placeholder="Description">
<span class="input-error-report"></span>

</div>

<br>


<center>
    <div style="width:35%;border:1px solid rgb(210,210,200);">
        
        
        <label>thumbnail</label>
<input style="border:none;" type="file"  name="file[]">
</div>
</center>
  <br>

<br>


<center>
    <div style="width:35%;border:1px solid rgb(210,210,200);">
        
        
        <label>music file</label>
<input style="border:none;" type="file"  name="file[]">
</div>
</center>
  <br>


<textarea rows="11" id="content" style="width:90%;padding:2px;" name="content" placeholder="Content..."></textarea>

<br>
<input type="submit"  name="submit" onclick="uploadMusic()" id="ddd" value="Submit!">
<input type="button" class="ddd" value="show!">

</form>

           
           
           
           </div>





<?php


include 'footer.php';

?>




<div class="boot" id="boot" style="width:30%;height:200px;position:fixed;bottom:-30px;left:-30px;display:none;background:white;box-shadow:0px 8px 8px 0px rgb(200,200,200);">
    <h6 style="background:black;margin:0;padding:6px;"><progress id="progressbar" value="" max="100"></progress><span style="color:red;float:right;cursor:pointer;"
    onclick="$('.boot').animate({left:'-31px',top:'-28px'},'fast');$('.boot').slideUp('slow');
                              ">&times;</span></h6>

    <div style="padding:5px;">
        
<small id="status"></small>
               
<small id="loaded"></small>
               

           
        
    </div>
    
</div>


<script src="musicpost.js"></script>
       
           <script>
           
           
               
                     $('#ddd').click(function(){
                         
                         
                              $('.boot').slideDown('fast');
                              $('.boot').animate({left:"31%",top:"28%"},"fast");
                              
                              
                              

                     });
               
                     $('.ddd').click(function(){
                         
                         
                              $('.boot').slideDown('fast');
                              $('.boot').animate({left:"31%",top:"28%"},"fast");
                              
                              
                              

                     });
                  
           </script>
</body>
</html>