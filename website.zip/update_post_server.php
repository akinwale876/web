<?php

 session_start();
 


require 'connection.php';






$errors = array();


if($conn){


    echo '<span style="color:green;font-size:9px;">conneted</span>';
}

if(isset($_POST['title'])){


if(!empty($_POST['title'])){


if(strlen($_POST['title']) > 6){

$title = trim($_POST['title']);


 $title= str_replace("'", '&#039;',  $title);

}else{

    array_push($errors, '<span style="color:red;">title length must be greater than 6</span>');


}











}else{
    array_push($errors, '<span style="color:red;">title is blank</span>');


}





}
else{

    array_push($errors, 'title is required');
}





































if(isset($_POST['id'])){

$id = $_POST['id'];


}



























if(isset($_POST['description'])){

    if(!empty($_POST['description'])){


if(strlen($_POST['description']) > 10){


$description = $_POST['description'];
$description = str_replace("'", '&#039;', $description);


 $description=preg_replace("/[^a-zA-Z0-9\- ]/"," ", $description);


}else{

    array_push($errors, '<span style="color:red;">description length must be greater than 10</span>');


}









    }else{

            array_push($errors, '<span style="color:red;">description is blank</span>');

    }





}
else{

    array_push($errors, 'description is required');
}








if(isset($_POST['content'])){

    if(!empty($_POST['content'])){


if(strlen($_POST['content']) > 100){


$content = $_POST['content'];
$content = str_replace("\n", '<p>', $content);
$content = str_replace("'", '&#039;', $content);

$content = str_replace("===", '<li>', $content);

$content = str_replace("[[[", '<h4>', $content);
$content = str_replace("]]]", '</h4>', $content);
$content = str_replace("[[", '<h2>', $content);
$content = str_replace("]]", '</h2>', $content);

$content = str_replace("((", '<center><img width="58%" src="', $content);
$content = str_replace("))", '"></center>', $content);


}else{

    array_push($errors, '<span style="color:red;">content length must be greater than 100 characters</span>');


}





}else{
    array_push($errors, '<span style="color:red;">content is blank</span>');


    }







}
else{

    array_push($errors, 'content is required');
}



if(isset($_FILES['file'])){

$file_name = $_FILES['file']['name'];
$file_size = $_FILES['file']['size'];
$file_type = $_FILES['file']['type'];
$file_tmp = $_FILES['file']['tmp_name'];


$extensions = array('jpg','png','jpeg');

$extract  = explode('.',$file_name);

$get_ext = end($extract);

if(!in_array($get_ext, $extensions)){


array_push($errors, '<span style="color:red;">extension not allowed</span>');
}
    


if($file_size > 2000000){


array_push($errors, '<span style="color:red;">file size must be 200000 bytes or less</span>');


}





}else{

    array_push($errors, '<span style="color:red;">please select file</span>');

}






if(empty($errors)){



if(move_uploaded_file($file_tmp, 'images/updated/' . $file_name)){
    
$picture_url = 'http://naijaramz.com/images/updated/' . $file_name;




$query =mysqli_query($conn,"UPDATE `posts` SET `title`= '$title', `description`= '$description', `content`='$content', `picture_url` ='$picture_url'  WHERE id='$id'");







if($query){

echo '<span style="color:green;">post updated successfully</span>';



}else{
echo '<span style="color:red;">post failed</span>';


}




}else{


   echo '<span style="color:red;">file upload fail</span>';
}






}else{




   foreach($errors as $key => $err){

echo $key .' ' .$err . '<br>';
   }





}




?>