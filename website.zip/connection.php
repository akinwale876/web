<?php

$conn = new mysqli('localhost:3306','naijara2_admin','0xYavRRO3aLv','naijara2_website');

?>