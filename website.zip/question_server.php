<?php 






require  'connection.php';



$errors = array();



if($conn){
    
    
    if(isset($_POST['name'])){
        
        if(!empty($_POST['name'])){
            
            $name = ucfirst(trim($_POST['name']));
            
            
              if(isset($_POST['check'])){
  

              if($_POST['check'] != ''){
  
if(!isset($_COOKIE['commentname'])) {


$cookie_name = "commentname";
$cookie_value = $name;
    
$cookie_email = "commentemail";
$cookie_email_value = $_POST['email'];
    
    setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");

    setcookie($cookie_email, $cookie_email_value, time() + (86400 * 30), "/");

    
} }

}
            
            
            
            
            
            
        }else{
            
            array_push($errors, '<p style="color:red;">your name is required, </p>');
        }
    }
    
    
    if(isset($_POST['email'])){
        
        if(!empty($_POST['email'])){
            
            $email = ucfirst(trim($_POST['email']));
            
            
        }else{
            
            array_push($errors, '<p style="color:red;">your email is required,</p>');
        }
    }
    
    if(isset($_POST['comment'])){
        
        if(!empty($_POST['comment'])){
            
            $comment = ucfirst(trim($_POST['comment']));
            
            
            
            
            $com_check = "SELECT * FROM questions WHERE question_title = '$comment' LIMIT 1";
            
            $que_check  = mysqli_query($conn,$com_check);
            
            if(mysqli_num_rows($que_check) > 0){
                
         array_push($errors, '<p style="color:red;">comment  already exist</p>');

            }
            
            
        }else{
            
            array_push($errors, '<p style="color:red;">comment  is required</p>');
        }
    }
    
    
    
    
}





















//display errors


if(!empty($errors)){
    
    foreach($errors as $value){
        
        
        echo $value ;
    }
    
}else{
    
    $date = date_create();
    $comment_id = $_POST['comment_id'];
    
    $date = date_timestamp_get($date);
    
    
    if(!empty($_POST['website'])){
        
            $website = $_POST['website'];

    }else{
        
            $website = 'none';

        
    }
    
    
    $question_id = $name . uniqid();
    
    $comm = "INSERT INTO `questions` (`question_title`,`username`,`tel`,`question_id`,`likes`,`date`) VALUES ('$comment','$name','$email','$question_id','0','$date')";
    
    
    if(mysqli_query($conn, $comm)){
        
        echo 'Ok';
    }else{
        
                echo '0';

    }
    
    
}


?>