
    <nav style="box-shadow: none;outline: none;" ><ul class="ul-list" id="nn">


    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>" title="updates and latest post" style="position:relative;text-indent:10px;">Home

        </a>

        </li>
        
        
        <span class="dott">.</span>

    <li>
        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/News" title="latest news informations" >Latest News</a>

        
    </li>
       <span class="dott">.</span>

   <!-- <li>
        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/Business" title="businesw" >Business</a>

        
    </li>-->
        
        
        
        
 <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/articles.php" >Articles</a>

        </li>
        <span class="dott">.</span>

        
 <li>
        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Sport" title="latest sport informations" > Sports</a>

        </li>




        <span class="dott">.</span>
    <li>
        
        

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Music"  style="position:relative;" title="latest naija gist" >Music
                          <span class="sit" style="position:absolute;top:-8px;padding:2px;display:inline-block;left:0;background:rgb(200,40,40);color:white;font-size:7px;">Hot</span>

        </a>

        </li>
           <span class="dott">.</span>


    <li>

<a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Entertainment" style="position:relative;" title="updates on latest entertaintaining gist" >Entertainment
        
        
        <?php
        
        $newD = time() - (86400 * 2);
        
        $entertainmentDate = mysqli_query($conn,"SELECT date FROM posts WHERE category='Entertainment' AND date > $newD");
        
        if(mysqli_num_rows($entertainmentDate) > 0){
        
     echo '<span class="sit" 
      style="position:absolute;top:-8px;padding:2px;display:inline-block;left:0;background:rgb(200,40,40);color:white;font-size:7px;">New</span>';
        
        }
        
        ?>
        
        
  
        </a>

        </li>

        <span class="dott">.</span>

    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/nollywood" style="position:relative;"  title="download latest yoruba movie " >
       Nollywood Movies
       
      
        <?php
        
        $newD = time() - (86400 * 2);
        
        $movieDate = mysqli_query($conn,"SELECT date FROM movies WHERE  date > $newD");
        
        if(mysqli_num_rows($movieDate) > 0){
        
     echo '<span class="sit" 
      style="position:absolute;top:-8px;padding:2px;display:inline-block;left:0;background:rgb(200,40,40);color:white;font-size:7px;">New</span>';
        
        }
        
        ?>
        
       </a>
       

</li>

           <span class="dott">.</span>


 <li>
        
        

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/Fashion" title="latest naija gist" >Fashion & styles</a>

        </li>

        <span class="dott">.</span>


    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/howto.php" >How to (learning tips)</a>

        </li>
   



       <span class="dott">.</span>

    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/forum.php" style="position:relative;" title="Ask question" >Talk Forum
        
        <span
      style="position:absolute;top:-8px;padding:2px;display:inline-block;left:21px;color:rgb(200,40,40);font-size:8px;"><i class="fa fa-users"></i></span>
        
        
        </a>

        </li>
        


        <span class="dott">.</span>


    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/SportPrediction">
       Sport Prediction</a>
</li>

  <li>

        <a href="javascript:void(0);" class="menu" onclick="clix()"> &#9776;</a>

        </li>
<style>
    
.movielist::after{

   content: "";
   border-color:white transparent  transparent  transparent ;
   border-style: solid;
   border-width: 6px;
   position: absolute;
  top:11px;
   



}




.movieshowcase{
min-width: 100px;
    display: none;
    position: absolute;bottom:-40px; 
    z-index:1;
}


#pshow:hover .movieshowcase{
min-width:208px;
    display: block;
}.movieshowcase a{

    display: block;
}


</style>


<script type="text/javascript">


  var x = 0;

function clix() {



  var nn = document.getElementById('nn');

if(x == 0){


    nn.style.height = "315px";

    x = 1;

    this.innerHTML = "&times;";
}
else{

        nn.style.height = "34px";
 x = 0;
}



}








    




</script>



<style>
    
    
    .sit::after{
        
        content:"";
        position:absolute;
        top:100%;
        left:30%;
        border-width:4px;
        border-color:rgb(200,40,40) transparent  transparent  transparent ;
        border-style:solid;
        
    }
    
</style>



    </ul></nav>