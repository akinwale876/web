<!DOCtype
 html>
 
 
 <?php
 
 require 'admin_init.php';
 
 
 
 
 
 if(!isset($_SESSION['access'])){
     
     echo '<script>
     
     
     window.location ="https://naijaramz.com/login"
     
     </script>';
     
 }
 
 
 
 ?>
 
 
 
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Welcome <?php echo $firstname; ?> - Author NaijaRamz</title>
<meta name="discription"
content="" />


<?php

include "head.php";

?>


</head>


<body>
      
      <?php 
      
      include 'header.php';
      
      ?>
    
<div class="wrapper" style="color:white;">
    <?php if($active == 0){
        
        echo '<h6>your account is not activated yet<a href="http://naijaramz.com/sendcode.php"> activate your account </a></h6>';
    }?>
    <a href="logout.php" style="float:right;">Logout</a>
<center>
    <h4>Welcome: <?php echo $firstname; ?></h4>
    
    <img src="https://naijaramz.com/profile/computer-icons-portable-network-graphics-user-profile-avatar-png-favpng-L1ihcbxsHbnBKBvjjfBMFGbb7.jpg" height="110px">
 <h3>Your Account Status: <i><?php echo $active;?></i></h3>


 <h3>Your Reg Ip: <i><?php echo $ip;?></i></h3>


 <h3>Your current Ip: <i><?php echo $_SERVER['REMOTE_ADDR'];?></i></h3>


 
 

<?php     if($active == 1) {echo '

<div class="input-container">
    
     <h3> <a href="https://naijaramz.com/add-post"><i class="fa fa-book">Add post </i></a></h3>

</div>
<div class="input-container">
    
     <h3> <a href="https://naijaramz.com/post-movie.php"><i class="fa fa-play">Add Movie</a></i></h3>

</div>
<div class="input-container">
    
     <h3><a href="https://naijaramz.com/post-music.php"><i class="fa fa-music">Add Music</i></a></h3>

</div><div class="input-container">
    
     <h3><a href="https://naijaramz.com/predict.php"><i class="fa fa-ball">Post Predict</i></a></h3>

</div><div class="input-container">
    
     <h3><a href="https://naijaramz.com/upload-image.php"><i class="fa fa-music">Upload Image</i></a></h3>

</div>

';
}
else{
    
    
          echo '<h4 style="color:red;">your account is not activated yet<a href="http://naijaramz.com/sendcode.php"> activate your account to unable you to post</a></h4>';

    
}


?>


</center>

<br>

<br>

<hr>

<br>

<br>

<?php 


$nam = $firstname.$lastname;


$list_post_query = mysqli_query($conn,"SELECT * FROM `posts`  WHERE author='$nam' ORDER BY id DESC LIMIT 6");

/*echo '<div class="main">';
if(mysqli_num_rows($list_post_query) > 0){
    
echo '<h5 style="box-shadow:0px 2px 2px 0px rgb(100,100,100);padding: 8px;font-size:11px;"></span>Your Recent post <span style="text-indent: 10px;"></h5>
' 

;


}
else{
    
    
echo '<h5 style="box-shadow:0px 6px 6px 0px rgb(100,100,100);background-color:white;color: black;padding: 8px;font-size:11px;"></span> no post to share <span style="text-indent: 10px;"></h5>
' ;
}




while($mov = mysqli_fetch_array($list_post_query)){

$list_title = $mov['title'];
$list_cleanurl = $mov['cleanurl'];
$list_image = $mov['picture_url'];
$list_description = $mov['description'];
$list_content = $mov['description'];

$list_category = $mov['category'];
$list_comments = $mov['comments'];
$list_comments_id = $mov['comment_id'];
$list_views = $mov['views'];

$list_date = date(' l  d / M / Y',$mov['date']);

$current_date = date_create();

$current_date = date_timestamp_get($current_date);


$count_date = $mov['date'];



$count_date =  ($current_date - $count_date);

$comment_post_query = mysqli_query($conn,"SELECT * FROM `comment` WHERE `comment_id` = '$list_comments_id'");


$num_post_query = mysqli_num_rows($comment_post_query);







  
  $days = floor($count_date / (60 * 60 * 24));
  $hours = floor(($count_date % (60 * 24)) / (1000 * 60 * 60));
 $minutes = floor(($count_date % ( 60)) / (1000 * 60));
 $seconds = floor(($count_date % (1000 * 60)) / 1000);
  
  

    
    $time = $minutes  . ' mins ';
    
$likes = $mov['likes'];
//

echo '<a style="text-decoration:none;color:black;" href="http://'. $_SERVER["SERVER_NAME"].'/'.$list_category.'/'.$list_cleanurl.'">

<div class="post" style="position:relative;">
<div class="post-title">
<h4 style="margin-bottom:8px;">'. ucfirst($list_title).'</h4>

<span class="hov" style="padding:3px;font-size:9px;>'.$list_category.'</span>


<b style="color:rgb(10,10,100);position:absolute;left:9px;bottom:10px;"><small><i class="fa fa-clock">'. $list_date .'</i>
</small><span style="margin-left:5px;color:red;font-size:10px;"><i class="fa fa-eye"></i>'.$list_views.' views</span></b><br><span class="content" id="one" style="color:rgb(140,140,140);font-family: Source Sans Pro,sans-serif 
;">
<span class="hov" style="padding:3px;border:none;font-weight:bold;">

<i class="fa fa-comment"></i>'.$num_post_query.'</span><span>

'. str_replace('h2','',str_replace('<h1>','',substr($list_content,0,120))) .'</span>
<span style="color:brown;font-weight:bold;margin-left:4px;font-size:9px;"></span>

</div>


    
</div></a>';

}


echo '</div>';*/






?>


</div>


<?php

include "footer.php";

?>


<style>
    
    
    .input-container{
        
        box-shadow:0px 8px 8px 0px rgb(200,200,200);
    }
    
    
</style>



</body>

</html>