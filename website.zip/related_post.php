
<?php





$relate_post_query = mysqli_query($conn,"SELECT * FROM posts WHERE tag='$tag' AND id !='$id' ORDER BY id DESC LIMIT 2 ");




if(mysqli_num_rows($relate_post_query) > 0){

}


if(mysqli_num_rows($relate_post_query) > 0){
echo '<h3>More of '.$tag.'</h4>' ;


}




while($movi = mysqli_fetch_array($relate_post_query)){

$rlist_title = $movi['title'];
$rlist_cleanurl = $movi['cleanurl'];
$rlist_cate = $movi['category'];
$rlist_image = $movi['picture_url'];
$rlist_date = date('l  d-M-Y',$movi['date']);





echo '<a style="text-decoration:none;color:black;" href="http://'. $_SERVER["SERVER_NAME"].'/'.$rlist_cate.'/'.$rlist_cleanurl.'">

<div class="post" style="position:relative;">

<img alt="'.$list_title.'" class="img" src="'.$rlist_image.'">

<div class="post-title">
<h4 style="margin-bottom:8px;">'. ucfirst($rlist_title).'</h4>
</div>


    
</div></a>';



}

if(mysqli_num_rows($relate_post_query) > 0){


}


?>