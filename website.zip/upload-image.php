
<?php


session_start();




if(!isset($_SESSION['access'])){
    
    header('location: http://naijaramz.com/login');
}




include 'head.php';

?>

<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">


	<title>Upload Image - NaijaRamz </title>

    

</head>
<body>
    <?php
    
      
       include 'header.php';
    
    ?>

                       <center><h1>Upload Picture to NaijaRamz </h1></center>

           <div class="wrapper">

                            
                            <form name="form" action="/" method="post" onsubmit="return false" enctype="multipart/form-data">


<center>
    <div style="width:35%;border:1px solid rgb(210,210,200);">
<input style="border:none;" type="file"  id="file">
</div>
</center>
  <br>


<br>
<input type="submit"  name="submit" onclick="upload()" id="ddd" value="Submit!">
<input type="button" class="ddd" value="show!">

</form>

           
           
           
           </div>





<?php


include 'footer.php';

?>




<div class="boot" id="boot" style="width:30%;height:200px;position:fixed;bottom:-30px;left:-30px;display:none;background:white;box-shadow:0px 8px 8px 0px rgb(200,200,200);">
    <h6 style="background:black;margin:0;padding:6px;"><progress id="progressbar" value="" max="100"></progress><span style="color:red;float:right;cursor:pointer;"
    onclick="$('.boot').animate({left:'-31px',top:'-28px'},'fast');$('.boot').slideUp('slow');
                              ">&times;</span></h6>

    <div style="padding:5px;">
        
<small id="status"></small>
               
<small id="loaded"></small>
               

           
        
    </div>
    
</div>


<script>
    
 
var title,description,category,tag,pic,content,data;

// preparing variables 

function _(el){

return document.getElementById(el);


}




// ..beginning of form validation...
function uploadMusic(){



title = _('title');
description =_('description');
pic =_('videoid');
file = _('file').files[0];

 category = _('category');
 tag = _('tag');
 content = _('content');


var formdata = new FormData();

formdata.append('title', title.value);
formdata.append('description', description.value);
formdata.append('picture_url', pic.value);
formdata.append('category', category.value);
formdata.append('tag', tag.value);
formdata.append('content', content.value);
formdata.append('file', file);


if (window.XMLHttpRequest) {
    // code for modern browsers
   var aja = new XMLHttpRequest();
 } else {
    // code for old IE browsers
   var aja = new ActiveXObject("Microsoft.XMLHTTP");
}


aja.upload.addEventListener('progress', progressHandle, false);
aja.addEventListener('load', completeHandle, false);
aja.addEventListener('error', errorHandle, false);
aja.addEventListener('abort', abortHandle, false);
aja.open("POST", "http://smartgist.com.ng/musicpost_server.php");
aja.send(formdata);




}


function progressHandle(event){

    _('loaded').innerHTML = "uploaded " + event.loaded + "bytes of " + event.total;

var percent = (event.loaded / event.total) * 100;

_('progressbar').value = Math.round(percent);
_('status').innerHTML = Math.round(percent) + "% upload... please wait";


}

function completeHandle(event){

_('status').innerHTML = event.target.responseText;

_('progressbar').value = 0;

}

function errorHandle(event){

_('status').innerHTML = "upload failed";



}

function abortHandle(event){

_('status').innerHTML = "upload aborted";



}

   
    
    
</script>
       
           <script>
           
           
           
           function laterClose(){
               
               
               setTimeout(function(){
                      
                                                    $('.boot').animate({left:"-31px",top:"28px"},"fast");

                      $('#boot').fadeOut(100);
                   
               },9000)
           }
           
           
               
                     $('#ddd').click(function(){
                         
                         
                              $('.boot').slideDown('fast');
                              $('.boot').animate({left:"31%",top:"28%"},"fast");
                              
                              
                              
                              laterClose();
                         
                     });
               
                     $('.ddd').click(function(){
                         
                         
                              $('.boot').slideDown('fast');
                              $('.boot').animate({left:"31%",top:"28%"},"fast");
                              
                              
                              
                              laterClose();
                         
                     });
                  
           </script>
</body>
</html>