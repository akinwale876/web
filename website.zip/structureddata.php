

<script type="application/ld+json">
{
  "@context": "https://schema.org/",
  "@type": "WebSite",
  "name": "Naijaramz",
  "url": "https://naijaramz.com/",
  "potentialAction": {
    "@type": "SearchAction",
    "target": "https://naijaramz.com/search_server.php?q={search_term_string}",
    "query-input": "required name=search_term_string"
  }
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Article",
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "<?php echo 'https://Naijaramz.com/'. $cleanurl;?>"
  },
  "headline": "<?php echo $title;?>",
  "description": "<?php echo $description;?>",
  "image": {
    "@type": "ImageObject",
    "url": "<?php echo $image; ?>",
    "width": 400,
    "height": 320
  },
  "author": {
    "@type": "Organization",
    "name": "<?php echo $author;?>"
  },  
  "publisher": {
    "@type": "Organization",
    "name": "https://web.facebook.com/naijaramz",
    "logo": {
      "@type": "ImageObject",
      "url": "https://naijaramz.com/",
      "width": 400,
      "height": 320
    }
  },
  "datePublished": "2020-01-10",
  "dateModified": "every day"
}
</script>

