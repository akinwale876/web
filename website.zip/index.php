<!DOCtype
 html>
<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Home - NaijaRamz | the people's site and your No 1 website for news , Entertaiments,sports, talks and lots more</title>

<?php

require 'start.php';

include "head.php";

?>


<meta name="description" content=" the people's site and your No 1 website for news , Entertaiments,sports, talks and lots more" />

		
<meta http-equiv="x-ua-compatible" content="IE=edge,chrome=1" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no " />
<link rel="canonical" href="https://naijaramz.com"  />


<meta property="og:site_name" content="Naija Ramz" />
<meta property="og:url" content="https://Naijaramz.com" />
<meta property="og:title" content="" />

<meta property="og:description" content="" />
<meta property="og:image" content="https://naijaramz.com/14763d33-d8f5-4a53-b4f8-10263d9de8b3_200x200.jpg"/>
<meta property="og:image:width" content="500" />
<meta property="og:image:height" content="500" />
<meta property="og:type" content="website" />


<meta name="medium" content="index" />

<!-- Indicate preferred brand name for Google to display -->
<script type="application/ld+json">
	{
		"@context": "https://schema.org",
		"@type":    "WebSite",
		"name":     "Naija Ramz",
		"url":      "https://naijaramz.com/"
	}
</script>
<script data-ad-client="ca-pub-5071187353490240" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
</head>


<body>


<?php

include "header.php";

?>

<div class="wrapper" >





<?php

include  root .'/app/models/init.php';


?>

<?php

include "sidebar.php";

?>

</div>


<?php

include "footer.php";

?>


<style>
    h5{
        
        margin-left:10px;
    }
    
    hr{
        
        border:1px solid rgb(220,200,200);
    }
    
</style>


</body>

</html>