<!DOCtype
 html>
 
 
 <?php
 
 require 'admin_init.php';
 
 
 
 
 ?>
 
 
 
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title><?php echo $_GET['url'] . ' Profile';  ?> - NaijaRamz</title>
<meta name="discription"
content="" />


<?php

include "head.php";

?>


</head>


<body>
      
      <?php 
      
      include 'header.php';
      
      ?>
    
<div class="wrapper" >
<center>
    <h2>Welcome To <?php echo $_GET['url']; ?> Profile</h2>
    
    <img src="http://naijaramz.com/profile/computer-icons-portable-network-graphics-user-profile-avatar-png-favpng-L1ihcbxsHbnBKBvjjfBMFGbb7.jpg" height="110px">


 <h3>Your current Ip: <i><?php echo $_SERVER['REMOTE_ADDR'];?></i></h3>



</center>

</div>


<?php

include "footer.php";

?>


<style>
    
    
    .input-container{
        
        box-shadow:0px 8px 8px 0px rgb(200,200,200);
    }
    
    
</style>



</body>

</html>